from urllib.parse import*
import requests
from bs4 import*
import socket
import re
from collections import deque
import dns.resolver
import csv
BLACK = '\033[30m'
RED = '\033[31m'
GREEN = '\033[32m'
YELLOW = '\033[33m' # orange on some systems
BLUE = '\033[34m'
MAGENAT = '\033[35m'
CYAN = '\033[36m'
LIGHT_GRAY = '\033[37m'
DARK_GRAY = '\033[90m'
BRIGHT_RED = '\033[91m'
BRIGHT_GREEN = '\033[92m'
BRIGHT_YELLOW = '\033[93m'
BRIGHT_BLUE = '\033[94m'
BRIGHT_MAGENTA = '\033[95m'
BRIGHT_CYAN = '\033[96m'
WHITE = '\033[97m'

RESET = '\033[0m'





frist_url=input("please enter link you want: ")
if not frist_url.startswith(('http://','https://')):
    url='https://'+frist_url


# my_resolver = dns.resolver.resolve(frist_url,'A')

# for sever in my_resolver:
#     hostname=sever.target.to_text()
#     print(f"Name Server:{hostname}")





get_org_link=urlparse(url).netloc
deps=set()
all_links=set()
queue=deque([(url,0)])

with open('recan.csv',mode="w",newline="",encoding="utf-8",) as cf:
    lists_as_thing=["omgh","Url","Ip","Number Phone","Emails",]
    w=csv.DictWriter(cf, fieldnames=lists_as_thing)
    w.writeheader()
    while queue:
        frist_url,depths=queue.popleft()

        if depths>2:
            continue
    
        if frist_url in deps:
            continue

        deps.add(frist_url)


        print(f"{BRIGHT_MAGENTA} omgh {depths}: {RESET} {frist_url}")


        give_recuest=requests.get(frist_url)
        if give_recuest.status_code==200:
            soup=BeautifulSoup(give_recuest.text,"html.parser")




            domain = urlparse(frist_url).netloc
            ip = socket.gethostbyname(domain)
            print(f"{CYAN}IP page:{RESET} {ip}")
        
            print("-" * 40)


            phone_example = [
            r'\+98[\s\-]?[\d۰-۹]{2,3}[\s\-]?[\d۰-۹]{3}[\s\-]?[\d۰-۹]{4}',
            r'0[\d۰-۹]{2,3}[\s\-]?[\d۰-۹]{3}[\s\-]?[\d۰-۹]{4}',
            r'[\d۰-۹]{3,4}[\s\-]?[\d۰-۹]{3,4}[\s\-]?[\d۰-۹]{3,4}',
            r'۰۹[\d۰-۹]{2}[\s\-]?[\d۰-۹]{3}[\s\-]?[\d۰-۹]{4}',
            r'۰۹[\d۰-۹]{9}', 
            ]
            phones = set()
            text = soup.get_text()
            for pattern in phone_example:
                matches = re.findall(pattern, text)
                for match in matches:
                 phones.add(match.strip())


            if phones:
                print(f"{BRIGHT_GREEN}Found Phone Numbers:{RESET}")
                for phone in phones:
                    print(f"{YELLOW}- {phone}{RESET}")

            else:
                print(f"{RED}No phone numbers found.{RESET}")

            email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
            emails = set(re.findall(email_pattern, text, re.IGNORECASE))

            for a in soup.find_all("a", href=True):
                if a['href'].startswith('mailto:'):
                    email = a['href'][7:].split('?')[0].strip()
                    if re.match(email_pattern, email):
                        emails.add(email)


            if emails:
                print(f"{GREEN}Found Emails:{RESET}")
                for email in emails:
                    print(f"{YELLOW}- {email}{RESET}")
            else:
                print(f"{RED}No emails found.{RESET}")


            for_find_this_ports = [21, 22, 23, 25, 53, 80, 110, 143, 443, 3306, 8080]

            for port in for_find_this_ports:
                s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)


                s.settimeout(1)


                natije=s.connect_ex((ip,port))


                if natije==0:
                    print(f"{BRIGHT_GREEN} port is open ✅:{port}{RESET}")


                else:
                    print(f"{BRIGHT_RED} this port isnt open ❌: {port}{RESET}")


                s.close()


            w.writerow({
                "omgh":depths,
                "Url":frist_url,
                "Ip":ip,
                "Number Phone":phones,
                "Emails":emails
            })

            for a in soup.find_all("a",href=True):
                href=a["href"]
                final_url=urljoin(frist_url,href)
                parsed=urlparse(final_url)
                all_links.add(frist_url)
        



                if parsed.scheme in ('http', 'https') and parsed.netloc.endswith(get_org_link):
                    if final_url not in all_links:
                        all_links.add(final_url)
                        if depths<2:
                            queue.append((final_url,depths+1))
        else:
            print(RED+f"error in get page{give_recuest.status_code}:{frist_url}"+RESET)
    title =soup.title.string
    print(f"{BLUE}title:{RESET} {title}")
            


    print(f"\n{BRIGHT_BLUE}Checking status code of collected URLs...{RESET}\n")


    User_error_code = [400, 401, 403, 404, 405, 422, 429]
    Success = [200, 201, 204]
    Redirect = [301, 302, 304]
    Server_error = [500, 502, 503, 504]

    for link in all_links:
        response = requests.get(link, timeout=5)
        code = response.status_code
        print("-" * 40)
        if code in Success:
            print(f"{GREEN}[{code}]{RESET} {link}")
        elif code in User_error_code:
            print(f"{RED}[{code}]{RESET} {link}")
        elif code in Redirect:
            print(f"{YELLOW}[{code}]{RESET} {link}")
        elif code in Server_error:
            print(f"{BLUE}[{code}]{RESET} {link}")
        else:
            print(f"{DARK_GRAY}[{code}]{RESET} {link}")

#  خط به خط این کد رو برام توضیح بده 